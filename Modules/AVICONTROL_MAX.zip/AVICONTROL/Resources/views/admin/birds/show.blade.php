@extends('avicontrol::layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-dove text-success me-2"></i>
                        Detalles del Lote: {{ $bird->batch_code }}
                    </h1>
                    <p class="text-muted mb-0">Información completa del lote de aves</p>
                </div>
                <div class="btn-group">
                    <a href="{{ route('avicontrol.admin.birds.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-1"></i>
                        Volver a la Lista
                    </a>
                    <a href="{{ route('avicontrol.admin.birds.edit', $bird->id) }}" class="btn btn-warning">
                        <i class="fas fa-edit me-1"></i>
                        Editar
                    </a>
                </div>
            </div>

            <div class="row">
                <!-- Información Principal -->
                <div class="col-lg-8">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-info-circle me-1"></i>
                                Información del Lote
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="fw-bold text-gray-600">Código de Lote:</td>
                                            <td>
                                                <span class="badge bg-primary fs-6">{{ $bird->batch_code }}</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Instalación:</td>
                                            <td>
                                                <i class="fas fa-warehouse text-primary me-1"></i>
                                                <a href="{{ route('avicontrol.admin.poultry_facilities.show', $bird->poultryFacility->id) }}" 
                                                   class="text-decoration-none">
                                                    {{ $bird->poultryFacility->name }}
                                                </a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Tipo de Ave:</td>
                                            <td>
                                                @switch($bird->bird_type)
                                                    @case('laying_hens')
                                                        <span class="badge bg-warning text-dark">
                                                            <i class="fas fa-egg me-1"></i>
                                                            Gallinas Ponedoras
                                                        </span>
                                                        @break
                                                    @case('broilers')
                                                        <span class="badge bg-info">
                                                            <i class="fas fa-drumstick-bite me-1"></i>
                                                            Pollos de Engorde
                                                        </span>
                                                        @break
                                                    @case('chicks')
                                                        <span class="badge bg-secondary">
                                                            <i class="fas fa-baby me-1"></i>
                                                            Pollitos
                                                        </span>
                                                        @break
                                                    @case('breeders')
                                                        <span class="badge bg-primary">
                                                            <i class="fas fa-heart me-1"></i>
                                                            Reproductores
                                                        </span>
                                                        @break
                                                @endswitch
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Estado:</td>
                                            <td>
                                                @switch($bird->status)
                                                    @case('active')
                                                        <span class="badge bg-success">
                                                            <i class="fas fa-check-circle me-1"></i>
                                                            Activo
                                                        </span>
                                                        @break
                                                    @case('sold')
                                                        <span class="badge bg-primary">
                                                            <i class="fas fa-dollar-sign me-1"></i>
                                                            Vendido
                                                        </span>
                                                        @break
                                                    @case('deceased')
                                                        <span class="badge bg-danger">
                                                            <i class="fas fa-skull me-1"></i>
                                                            Fallecido
                                                        </span>
                                                        @break
                                                    @case('transferred')
                                                        <span class="badge bg-warning text-dark">
                                                            <i class="fas fa-exchange-alt me-1"></i>
                                                            Transferido
                                                        </span>
                                                        @break
                                                @endswitch
                                            </td>
                                        </tr>
                                        @if($bird->breed)
                                        <tr>
                                            <td class="fw-bold text-gray-600">Raza:</td>
                                            <td>{{ $bird->breed }}</td>
                                        </tr>
                                        @endif
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="fw-bold text-gray-600">Cantidad Actual:</td>
                                            <td>
                                                <span class="h5 text-success">{{ number_format($bird->quantity) }}</span> aves
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Cantidad Inicial:</td>
                                            <td>{{ number_format($bird->initial_quantity) }} aves</td>
                                        </tr>
                                        @if($bird->initial_quantity != $bird->quantity)
                                        <tr>
                                            <td class="fw-bold text-gray-600">Diferencia:</td>
                                            <td>
                                                <span class="text-{{ $bird->quantity < $bird->initial_quantity ? 'danger' : 'success' }}">
                                                    {{ $bird->quantity - $bird->initial_quantity > 0 ? '+' : '' }}{{ number_format($bird->quantity - $bird->initial_quantity) }} aves
                                                </span>
                                            </td>
                                        </tr>
                                        @endif
                                        <tr>
                                            <td class="fw-bold text-gray-600">Fecha de Ingreso:</td>
                                            <td>
                                                {{ \Carbon\Carbon::parse($bird->entry_date)->format('d/m/Y') }}
                                                <br><small class="text-muted">{{ \Carbon\Carbon::parse($bird->entry_date)->diffForHumans() }}</small>
                                            </td>
                                        </tr>
                                        @if($bird->age_weeks)
                                        <tr>
                                            <td class="fw-bold text-gray-600">Edad:</td>
                                            <td>{{ $bird->age_weeks }} semanas</td>
                                        </tr>
                                        @endif
                                        @if($bird->average_weight)
                                        <tr>
                                            <td class="fw-bold text-gray-600">Peso Promedio:</td>
                                            <td>{{ $bird->average_weight }} kg por ave</td>
                                        </tr>
                                        @endif
                                    </table>
                                </div>
                            </div>

                            @if($bird->notes)
                            <div class="row mt-3">
                                <div class="col-12">
                                    <h6 class="text-gray-600">Notas:</h6>
                                    <div class="alert alert-light">
                                        {{ $bird->notes }}
                                    </div>
                                </div>
                            </div>
                            @endif
                        </div>
                    </div>

                    <!-- Información Económica -->
                    @if($bird->purchase_price || $bird->supplier)
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-success">
                                <i class="fas fa-dollar-sign me-1"></i>
                                Información Económica
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                @if($bird->purchase_price)
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="fw-bold text-gray-600">Precio por Ave:</td>
                                            <td>${{ number_format($bird->purchase_price, 2) }}</td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Inversión Total:</td>
                                            <td>
                                                <span class="h5 text-success">
                                                    ${{ number_format($bird->purchase_price * $bird->initial_quantity, 2) }}
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="fw-bold text-gray-600">Valor Actual:</td>
                                            <td>
                                                <span class="h5 text-info">
                                                    ${{ number_format($bird->purchase_price * $bird->quantity, 2) }}
                                                </span>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                @endif
                                @if($bird->supplier)
                                <div class="col-md-6">
                                    <table class="table table-borderless">
                                        <tr>
                                            <td class="fw-bold text-gray-600">Proveedor:</td>
                                            <td>{{ $bird->supplier }}</td>
                                        </tr>
                                    </table>
                                </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endif
                </div>

                <!-- Panel Lateral -->
                <div class="col-lg-4">
                    <!-- Estadísticas Rápidas -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-info">
                                <i class="fas fa-chart-pie me-1"></i>
                                Estadísticas
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="text-center">
                                <div class="mb-3">
                                    <h4 class="text-primary">{{ number_format($bird->quantity) }}</h4>
                                    <p class="text-muted mb-0">Aves Actuales</p>
                                </div>
                                
                                @if($bird->average_weight)
                                <div class="mb-3">
                                    <h4 class="text-success">{{ number_format($bird->average_weight * $bird->quantity, 2) }} kg</h4>
                                    <p class="text-muted mb-0">Peso Total Estimado</p>
                                </div>
                                @endif

                                @if($bird->age_weeks)
                                <div class="mb-3">
                                    <h4 class="text-warning">{{ $bird->age_weeks }}</h4>
                                    <p class="text-muted mb-0">Semanas de Edad</p>
                                </div>
                                @endif

                                <div class="mb-3">
                                    <h4 class="text-info">{{ \Carbon\Carbon::parse($bird->entry_date)->diffInDays() }}</h4>
                                    <p class="text-muted mb-0">Días en la Instalación</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Información de la Instalación -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-warning">
                                <i class="fas fa-warehouse me-1"></i>
                                Instalación
                            </h6>
                        </div>
                        <div class="card-body">
                            <h6>{{ $bird->poultryFacility->name }}</h6>
                            <p class="text-muted">{{ $bird->poultryFacility->description }}</p>
                            
                            <div class="row text-center">
                                <div class="col-6">
                                    <div class="border-end">
                                        <h5 class="text-primary">{{ number_format($bird->poultryFacility->capacity) }}</h5>
                                        <small class="text-muted">Capacidad Total</small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <h5 class="text-success">{{ number_format($bird->poultryFacility->total_active_birds) }}</h5>
                                    <small class="text-muted">Aves Actuales</small>
                                </div>
                            </div>

                            <div class="mt-3">
                                <div class="d-flex justify-content-between mb-1">
                                    <span class="text-muted">Ocupación</span>
                                    <span class="text-muted">{{ number_format($bird->poultryFacility->occupancy_percentage, 1) }}%</span>
                                </div>
                                <div class="progress">
                                    <div class="progress-bar 
                                        @if($bird->poultryFacility->occupancy_percentage < 70) bg-success
                                        @elseif($bird->poultryFacility->occupancy_percentage < 90) bg-warning
                                        @else bg-danger @endif" 
                                        role="progressbar" 
                                        style="width: {{ $bird->poultryFacility->occupancy_percentage }}%">
                                    </div>
                                </div>
                            </div>

                            <div class="mt-3">
                                <a href="{{ route('avicontrol.admin.poultry_facilities.show', $bird->poultryFacility->id) }}" 
                                   class="btn btn-outline-primary btn-sm w-100">
                                    <i class="fas fa-eye me-1"></i>
                                    Ver Detalles de la Instalación
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Acciones Rápidas -->
                    <div class="card shadow">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-danger">
                                <i class="fas fa-cogs me-1"></i>
                                Acciones
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="{{ route('avicontrol.admin.birds.edit', $bird->id) }}" 
                                   class="btn btn-warning">
                                    <i class="fas fa-edit me-1"></i>
                                    Editar Lote
                                </a>
                                
                                <button type="button" 
                                        class="btn btn-danger" 
                                        onclick="confirmDelete({{ $bird->id }}, '{{ $bird->batch_code }}')">
                                    <i class="fas fa-trash me-1"></i>
                                    Eliminar Lote
                                </button>
                                
                                <a href="{{ route('avicontrol.admin.birds.index') }}" 
                                   class="btn btn-secondary">
                                    <i class="fas fa-list me-1"></i>
                                    Ver Todos los Lotes
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal de confirmación para eliminar -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">
                    <i class="fas fa-exclamation-triangle text-warning me-2"></i>
                    Confirmar Eliminación
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>¿Está seguro de que desea eliminar el lote <strong id="batchCodeToDelete"></strong>?</p>
                <p class="text-muted">Esta acción no se puede deshacer y se perderán todos los datos asociados.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form id="deleteForm" method="POST" style="display: inline;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-trash me-1"></i>
                        Eliminar
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    function confirmDelete(birdId, batchCode) {
        document.getElementById('batchCodeToDelete').textContent = batchCode;
        document.getElementById('deleteForm').action = '{{ route("avicontrol.admin.birds.destroy", ":id") }}'.replace(':id', birdId);
        
        var deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        deleteModal.show();
    }
</script>
@endsection

@section('styles')
<style>
    .card {
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15) !important;
    }
    
    .table-borderless td {
        border: none;
        padding: 0.5rem 0;
    }
    
    .fw-bold {
        font-weight: 600 !important;
    }
    
    .text-gray-600 {
        color: #6c757d !important;
    }
    
    .border-end {
        border-right: 1px solid #dee2e6 !important;
    }
    
    .progress {
        height: 8px;
    }
    
    .btn-group .btn {
        margin-right: 5px;
    }
</style>
@endsection
