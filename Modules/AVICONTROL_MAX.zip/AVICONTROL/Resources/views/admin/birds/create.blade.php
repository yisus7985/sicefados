@extends('avicontrol::layouts.master')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h1 class="h3 mb-0 text-gray-800">
                        <i class="fas fa-plus-circle text-success me-2"></i>
                        Registrar Nuevo Lote de Aves
                    </h1>
                    <p class="text-muted mb-0">Complete la información del nuevo lote de aves</p>
                </div>
                <a href="{{ route('avicontrol.admin.birds.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left me-1"></i>
                    Volver a la Lista
                </a>
            </div>

            <!-- Formulario -->
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-dove me-1"></i>
                        Información del Lote
                    </h6>
                </div>
                <div class="card-body">
                    <form action="{{ route('avicontrol.admin.birds.store') }}" method="POST" id="birdForm">
                        @csrf
                        
                        <div class="row">
                            <!-- Información Básica -->
                            <div class="col-md-6">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Información Básica
                                </h5>
                                
                                <div class="mb-3">
                                    <label for="poultry_facility_id" class="form-label">
                                        Instalación Avícola <span class="text-danger">*</span>
                                    </label>
                                    <select name="poultry_facility_id" id="poultry_facility_id" 
                                            class="form-select @error('poultry_facility_id') is-invalid @enderror" 
                                            required onchange="updateFacilityInfo()">
                                        <option value="">Seleccione una instalación</option>
                                        @foreach($poultryFacilities as $facility)
                                            <option value="{{ $facility->id }}" 
                                                    {{ old('poultry_facility_id') == $facility->id ? 'selected' : '' }}
                                                    data-capacity="{{ $facility->capacity }}"
                                                    data-current="{{ $facility->total_active_birds }}"
                                                    data-available="{{ $facility->available_capacity }}">
                                                {{ $facility->name }} (Disponible: {{ $facility->available_capacity }} aves)
                                            </option>
                                        @endforeach
                                    </select>
                                    @error('poultry_facility_id')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div id="facilityInfo" class="mt-2" style="display: none;">
                                        <div class="alert alert-info">
                                            <strong>Información de la Instalación:</strong><br>
                                            <span id="facilityCapacity"></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="batch_code" class="form-label">
                                        Código de Lote <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" name="batch_code" id="batch_code" 
                                           class="form-control @error('batch_code') is-invalid @enderror" 
                                           value="{{ old('batch_code') }}" 
                                           placeholder="Ej: LOTE-2025-001" 
                                           required>
                                    @error('batch_code')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">Código único para identificar este lote</div>
                                </div>

                                <div class="mb-3">
                                    <label for="bird_type" class="form-label">
                                        Tipo de Ave <span class="text-danger">*</span>
                                    </label>
                                    <select name="bird_type" id="bird_type" 
                                            class="form-select @error('bird_type') is-invalid @enderror" 
                                            required>
                                        <option value="">Seleccione el tipo de ave</option>
                                        <option value="laying_hens" {{ old('bird_type') == 'laying_hens' ? 'selected' : '' }}>
                                            Gallinas Ponedoras
                                        </option>
                                        <option value="broilers" {{ old('bird_type') == 'broilers' ? 'selected' : '' }}>
                                            Pollos de Engorde
                                        </option>
                                        <option value="chicks" {{ old('bird_type') == 'chicks' ? 'selected' : '' }}>
                                            Pollitos
                                        </option>
                                        <option value="breeders" {{ old('bird_type') == 'breeders' ? 'selected' : '' }}>
                                            Reproductores
                                        </option>
                                    </select>
                                    @error('bird_type')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="quantity" class="form-label">
                                        Cantidad de Aves <span class="text-danger">*</span>
                                    </label>
                                    <input type="number" name="quantity" id="quantity" 
                                           class="form-control @error('quantity') is-invalid @enderror" 
                                           value="{{ old('quantity') }}" 
                                           min="1" 
                                           placeholder="Número de aves en el lote" 
                                           required
                                           onchange="validateCapacity()">
                                    @error('quantity')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div id="capacityWarning" class="form-text text-warning" style="display: none;">
                                        <i class="fas fa-exclamation-triangle me-1"></i>
                                        La cantidad excede la capacidad disponible
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="entry_date" class="form-label">
                                        Fecha de Ingreso <span class="text-danger">*</span>
                                    </label>
                                    <input type="date" name="entry_date" id="entry_date" 
                                           class="form-control @error('entry_date') is-invalid @enderror" 
                                           value="{{ old('entry_date', date('Y-m-d')) }}" 
                                           required>
                                    @error('entry_date')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>

                            <!-- Información Adicional -->
                            <div class="col-md-6">
                                <h5 class="text-primary mb-3">
                                    <i class="fas fa-clipboard-list me-1"></i>
                                    Información Adicional
                                </h5>

                                <div class="mb-3">
                                    <label for="age_weeks" class="form-label">Edad (Semanas)</label>
                                    <input type="number" name="age_weeks" id="age_weeks" 
                                           class="form-control @error('age_weeks') is-invalid @enderror" 
                                           value="{{ old('age_weeks') }}" 
                                           min="0" max="200" 
                                           placeholder="Edad en semanas">
                                    @error('age_weeks')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="breed" class="form-label">Raza</label>
                                    <input type="text" name="breed" id="breed" 
                                           class="form-control @error('breed') is-invalid @enderror" 
                                           value="{{ old('breed') }}" 
                                           placeholder="Ej: Rhode Island Red, Leghorn">
                                    @error('breed')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="average_weight" class="form-label">Peso Promedio (kg)</label>
                                    <input type="number" name="average_weight" id="average_weight" 
                                           class="form-control @error('average_weight') is-invalid @enderror" 
                                           value="{{ old('average_weight') }}" 
                                           step="0.01" min="0" 
                                           placeholder="Peso promedio por ave">
                                    @error('average_weight')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="purchase_price" class="form-label">Precio de Compra (por ave)</label>
                                    <div class="input-group">
                                        <span class="input-group-text">$</span>
                                        <input type="number" name="purchase_price" id="purchase_price" 
                                               class="form-control @error('purchase_price') is-invalid @enderror" 
                                               value="{{ old('purchase_price') }}" 
                                               step="0.01" min="0" 
                                               placeholder="0.00">
                                    </div>
                                    @error('purchase_price')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="supplier" class="form-label">Proveedor</label>
                                    <input type="text" name="supplier" id="supplier" 
                                           class="form-control @error('supplier') is-invalid @enderror" 
                                           value="{{ old('supplier') }}" 
                                           placeholder="Nombre del proveedor">
                                    @error('supplier')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notas</label>
                                    <textarea name="notes" id="notes" 
                                              class="form-control @error('notes') is-invalid @enderror" 
                                              rows="3" 
                                              placeholder="Observaciones adicionales sobre el lote">{{ old('notes') }}</textarea>
                                    @error('notes')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <!-- Resumen del Lote -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">
                                            <i class="fas fa-calculator me-1"></i>
                                            Resumen del Lote
                                        </h6>
                                        <div class="row">
                                            <div class="col-md-3">
                                                <strong>Inversión Total:</strong>
                                                <div id="totalInvestment" class="h5 text-success">$0.00</div>
                                            </div>
                                            <div class="col-md-3">
                                                <strong>Costo por Ave:</strong>
                                                <div id="costPerBird" class="h5 text-info">$0.00</div>
                                            </div>
                                            <div class="col-md-3">
                                                <strong>Peso Total Estimado:</strong>
                                                <div id="totalWeight" class="h5 text-warning">0 kg</div>
                                            </div>
                                            <div class="col-md-3">
                                                <strong>Ocupación del Galpón:</strong>
                                                <div id="occupancyPercentage" class="h5 text-primary">0%</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Botones -->
                        <div class="row mt-4">
                            <div class="col-12">
                                <div class="d-flex justify-content-end gap-2">
                                    <a href="{{ route('avicontrol.admin.birds.index') }}" class="btn btn-secondary">
                                        <i class="fas fa-times me-1"></i>
                                        Cancelar
                                    </a>
                                    <button type="submit" class="btn btn-success">
                                        <i class="fas fa-save me-1"></i>
                                        Registrar Lote
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    function updateFacilityInfo() {
        const select = document.getElementById('poultry_facility_id');
        const selectedOption = select.options[select.selectedIndex];
        const facilityInfo = document.getElementById('facilityInfo');
        const facilityCapacity = document.getElementById('facilityCapacity');
        
        if (selectedOption.value) {
            const capacity = selectedOption.dataset.capacity;
            const current = selectedOption.dataset.current;
            const available = selectedOption.dataset.available;
            
            facilityCapacity.innerHTML = `
                <strong>Capacidad Total:</strong> ${capacity} aves<br>
                <strong>Aves Actuales:</strong> ${current} aves<br>
                <strong>Capacidad Disponible:</strong> ${available} aves
            `;
            facilityInfo.style.display = 'block';
            
            validateCapacity();
        } else {
            facilityInfo.style.display = 'none';
        }
        
        updateSummary();
    }

    function validateCapacity() {
        const select = document.getElementById('poultry_facility_id');
        const selectedOption = select.options[select.selectedIndex];
        const quantity = parseInt(document.getElementById('quantity').value) || 0;
        const warning = document.getElementById('capacityWarning');
        
        if (selectedOption.value && quantity > 0) {
            const available = parseInt(selectedOption.dataset.available);
            
            if (quantity > available) {
                warning.style.display = 'block';
                warning.innerHTML = `
                    <i class="fas fa-exclamation-triangle me-1"></i>
                    La cantidad (${quantity}) excede la capacidad disponible (${available} aves)
                `;
            } else {
                warning.style.display = 'none';
            }
        } else {
            warning.style.display = 'none';
        }
        
        updateSummary();
    }

    function updateSummary() {
        const quantity = parseInt(document.getElementById('quantity').value) || 0;
        const price = parseFloat(document.getElementById('purchase_price').value) || 0;
        const weight = parseFloat(document.getElementById('average_weight').value) || 0;
        
        const select = document.getElementById('poultry_facility_id');
        const selectedOption = select.options[select.selectedIndex];
        
        // Cálculos
        const totalInvestment = quantity * price;
        const totalWeight = quantity * weight;
        
        let occupancyPercentage = 0;
        if (selectedOption.value) {
            const capacity = parseInt(selectedOption.dataset.capacity);
            const current = parseInt(selectedOption.dataset.current);
            occupancyPercentage = ((current + quantity) / capacity * 100).toFixed(1);
        }
        
        // Actualizar elementos
        document.getElementById('totalInvestment').textContent = `$${totalInvestment.toFixed(2)}`;
        document.getElementById('costPerBird').textContent = `$${price.toFixed(2)}`;
        document.getElementById('totalWeight').textContent = `${totalWeight.toFixed(2)} kg`;
        document.getElementById('occupancyPercentage').textContent = `${occupancyPercentage}%`;
    }

    // Event listeners
    document.getElementById('quantity').addEventListener('input', validateCapacity);
    document.getElementById('purchase_price').addEventListener('input', updateSummary);
    document.getElementById('average_weight').addEventListener('input', updateSummary);

    // Generar código de lote automático
    document.getElementById('bird_type').addEventListener('change', function() {
        const batchCodeInput = document.getElementById('batch_code');
        if (!batchCodeInput.value) {
            const birdType = this.value;
            const date = new Date();
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            
            let prefix = '';
            switch(birdType) {
                case 'laying_hens': prefix = 'GP'; break;
                case 'broilers': prefix = 'PE'; break;
                case 'chicks': prefix = 'PO'; break;
                case 'breeders': prefix = 'RE'; break;
                default: prefix = 'LT'; break;
            }
            
            const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
            batchCodeInput.value = `${prefix}-${year}${month}-${randomNum}`;
        }
    });
</script>
@endsection

@section('styles')
<style>
    .card {
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15) !important;
    }
    
    .form-label {
        font-weight: 600;
        color: #5a5c69;
    }
    
    .text-danger {
        color: #e74a3b !important;
    }
    
    .btn-group .btn {
        margin-right: 5px;
    }
    
    .alert-info {
        background-color: #d1ecf1;
        border-color: #bee5eb;
        color: #0c5460;
    }
    
    #capacityWarning {
        font-weight: 600;
    }
</style>
@endsection
