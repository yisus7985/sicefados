@extends('avicontrol::layouts.master')



@section('content')
    <h1>hello word</h1>

    <p>
        this view is loaded from module: {!!config('avicontrol.name') !!}


    </p>
    
@endsection